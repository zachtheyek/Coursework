//Chp 10, Q7

#ifndef _DAYTYPE_CLASS_
#define _DAYTYPE_CLASS_

#include <string>
using namespace std;

class dayType {
public:
  //constructors
  dayType();
  dayType(string val);

  //other operations
  void setDay(string val);
  void printDay() const;
  string getToday() const;
  string getTomorrow() const;
  string getYesterday() const;
  string addDay(int val);

private:
  string day;
};

#include "daytype.cpp"
#endif
