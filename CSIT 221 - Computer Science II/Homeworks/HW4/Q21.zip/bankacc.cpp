#include <iostream>
#include <string>
#include "bankacc.h"
using namespace std;

int bankAccount::newAccNum = 1000;

bankAccount::bankAccount() {
  accName = "";
  accNum = newAccNum++;
  accType = "checking";
  balance = 0.0;
  interestRate = 0.0;
}

void bankAccount::setName(string name) {
  accName = name;
}

void bankAccount::setNum(int num) {
  if(num < 0) {
    cout << "Negative argument provided, absolute value taken instead." << endl;
    num *= -1;
  }
  accNum = num;
}

void bankAccount::setType(string type) {
  if ((type == "checking") || (type == "saving")) {
    accType = type;
  }
  else {
    cout << "Invalid argument provided, object.accType set to \"checking\"." << endl;
  }
}

void bankAccount::setBal(double bal) {
  balance = bal;
}

void bankAccount::setRate(double rate) {
  interestRate = rate;
}

void bankAccount::printName() const {
  cout << "Account holder's name: " << accName << endl;
}

void bankAccount::printNum() const {
  cout << "Account number: " << accNum << endl;
}

void bankAccount::printType() const {
  cout << "Account type: " << accType << endl;
}

void bankAccount::printBal() const {
  cout << "Balance: " << balance << endl;
}

void bankAccount::printRate() const {
  cout << "Interest rate: " << interestRate << endl;
}

string bankAccount::getName() const {
  return accName;
}

int bankAccount::getNum() const {
  return accNum;
}

string bankAccount::getType() const {
  return accType;
}

double bankAccount::getBal() const {
  return balance;
}

double bankAccount::getRate() const {
  return interestRate;
}