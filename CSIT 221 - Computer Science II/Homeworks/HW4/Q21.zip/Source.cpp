//Chp 10, Q21
#include <iostream>
#include <string>
#include "bankacc.h"
using namespace std;


int main() {

  bankAccount accArray[10];

  //setting and printing account name
  accArray[0].setName("Xi Yek");
  accArray[0].printName();
  cout << endl;

  //setting and printing account number
  accArray[2].printNum();
  accArray[2].setNum(2773);
  cout << "Account number: " << accArray[8].getNum() << endl << endl;

  //setting and printing account type, balance, and interest rate
  accArray[5].setType("saving");
  accArray[5].setBal(10566.94);
  accArray[5].setRate(2.884);
  accArray[5].printType();
  accArray[5].printBal();
  accArray[5].printRate();
  cout << endl;

  //edge cases
  accArray[7].setNum(-7618);
  cout << "Account number: " << accArray[7].getNum() << endl << endl;
  accArray[8].setType("holding");
  cout << "Account type: " << accArray[8].getType() << endl;


	return 0;
}