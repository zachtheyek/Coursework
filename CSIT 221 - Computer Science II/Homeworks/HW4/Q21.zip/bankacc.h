#ifndef _BANKACC_CLASS_
#define _BANKACC_CLASS_

#include <string>
using namespace std;

class bankAccount {
public:
  static int newAccNum;

  //default constructor
  bankAccount();

  //functions to set private data members
  void setName(string name);
  void setNum(int num);
  void setType(string type);
  void setBal(double bal);
  void setRate(double rate);

  //functions to print private data members
  void printName() const;
  void printNum() const;
  void printType() const;
  void printBal() const;
  void printRate() const;

  //functions to return private data members
  string getName() const;
  int getNum() const;
  string getType() const;
  double getBal() const;
  double getRate() const;

private:
  string accName;
  int accNum;
  string accType;
  double balance;
  double interestRate;
};

#include "bankacc.cpp"
#endif